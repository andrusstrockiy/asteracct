:mod:`pyrad.server` -- basic server
===================================


.. automodule:: pyrad.server

  .. autoclass:: RemoteHost
    :members:

  .. autoclass:: ServerPacketError
    :members:

  .. autoclass:: Server
    :members:

