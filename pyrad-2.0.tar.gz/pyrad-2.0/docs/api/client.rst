:mod:`pyrad.client` -- basic client
===================================


.. automodule:: pyrad.client

  .. autoclass:: Timeout
    :members:

  .. autoclass:: Client
    :members:

