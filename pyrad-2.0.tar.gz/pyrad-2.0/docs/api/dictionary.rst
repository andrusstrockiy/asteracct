:mod:`pyrad.dictionary` -- RADIUS dictionary
============================================


.. automodule:: pyrad.dictionary

  .. autoclass:: ParseError
    :members:

  .. autoclass:: Dictionary
    :members:

